var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// api/_netlify.js
var netlify_exports = {};
__export(netlify_exports, {
  createDevEvent: () => createDevEvent,
  jsonResponse: () => jsonResponse,
  parseEventBody: () => parseEventBody,
  sendNetlifyHandler: () => sendNetlifyHandler
});
module.exports = __toCommonJS(netlify_exports);
var JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8"
};
function parseEventBody(event) {
  if (!event?.body) return {};
  if (typeof event.body === "object") return event.body;
  try {
    return JSON.parse(event.body);
  } catch {
    return {};
  }
}
function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: JSON_HEADERS,
    body: JSON.stringify(payload)
  };
}
function createDevEvent(method, body) {
  return {
    httpMethod: method,
    body: JSON.stringify(body ?? {})
  };
}
async function sendNetlifyHandler(handler, req, res, body) {
  const result = await handler(createDevEvent(req.method, body));
  res.statusCode = result?.statusCode || 500;
  Object.entries(result?.headers || JSON_HEADERS).forEach(([key, value]) => {
    res.setHeader(key, value);
  });
  res.end(result?.body || JSON.stringify({ error: "API \uCC98\uB9AC \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4." }));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createDevEvent,
  jsonResponse,
  parseEventBody,
  sendNetlifyHandler
});
