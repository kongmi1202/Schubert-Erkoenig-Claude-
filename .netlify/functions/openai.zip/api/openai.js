var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// api/openai.js
var openai_exports = {};
__export(openai_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(openai_exports);

// api/_shared.js
function getOpenAiApiKey() {
  const key = process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY;
  return typeof key === "string" ? key.trim() : "";
}
async function callOpenAiResponses({ model, input, textFormat }) {
  const apiKey = getOpenAiApiKey();
  if (!apiKey) {
    const err = new Error("OPENAI_API_KEY\uAC00 \uC124\uC815\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    err.statusCode = 500;
    throw err;
  }
  const payload = { model, input };
  if (textFormat) payload.text = { format: textFormat };
  const openAiRes = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify(payload)
  });
  const json = await openAiRes.json();
  if (!openAiRes.ok) {
    const err = new Error(typeof json?.error?.message === "string" ? json.error.message : "OpenAI API \uD638\uCD9C \uC2E4\uD328");
    err.statusCode = openAiRes.status;
    err.payload = json;
    throw err;
  }
  return json;
}

// api/_netlify.js
var JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8"
};
function parseEventBody(event) {
  if (!event?.body) return {};
  if (typeof event.body === "object") return event.body;
  try {
    return JSON.parse(event.body);
  } catch {
    return {};
  }
}
function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: JSON_HEADERS,
    body: JSON.stringify(payload)
  };
}

// api/openai.js
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return jsonResponse(405, { error: "Method Not Allowed" });
  }
  const body = parseEventBody(event);
  const model = typeof body?.model === "string" ? body.model.trim() : "";
  const input = body?.input;
  const textFormat = body?.textFormat;
  if (!model || input === void 0 || input === null) {
    return jsonResponse(400, { error: "model\uACFC input\uC774 \uD544\uC694\uD569\uB2C8\uB2E4." });
  }
  try {
    const json = await callOpenAiResponses({ model, input, textFormat });
    return jsonResponse(200, json);
  } catch (err) {
    const status = err?.statusCode || 500;
    return jsonResponse(status, {
      error: err?.message || "OpenAI API \uD638\uCD9C \uC2E4\uD328",
      details: err?.payload || null
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
