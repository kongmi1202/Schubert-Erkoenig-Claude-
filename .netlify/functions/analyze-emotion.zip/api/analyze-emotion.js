var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// api/analyze-emotion.js
var analyze_emotion_exports = {};
__export(analyze_emotion_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(analyze_emotion_exports);

// api/_shared.js
function extractTextFromResponse(json) {
  if (typeof json?.output_text === "string") return json.output_text;
  const texts = [];
  (json?.output || []).forEach((item) => {
    (item?.content || []).forEach((contentItem) => {
      if (typeof contentItem?.text === "string") texts.push(contentItem.text);
    });
  });
  return texts.join("\n").trim();
}
function getOpenAiApiKey() {
  const key = process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY;
  return typeof key === "string" ? key.trim() : "";
}
async function callOpenAiResponses({ model, input }) {
  const apiKey = getOpenAiApiKey();
  if (!apiKey) {
    const err = new Error("OPENAI_API_KEY\uAC00 \uC124\uC815\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    err.statusCode = 500;
    throw err;
  }
  const openAiRes = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({ model, input })
  });
  const json = await openAiRes.json();
  if (!openAiRes.ok) {
    const err = new Error(typeof json?.error?.message === "string" ? json.error.message : "OpenAI API \uD638\uCD9C \uC2E4\uD328");
    err.statusCode = openAiRes.status;
    err.payload = json;
    throw err;
  }
  return json;
}

// api/_netlify.js
var JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8"
};
function parseEventBody(event) {
  if (!event?.body) return {};
  if (typeof event.body === "object") return event.body;
  try {
    return JSON.parse(event.body);
  } catch {
    return {};
  }
}
function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: JSON_HEADERS,
    body: JSON.stringify(payload)
  };
}

// api/analyze-emotion.js
var EMOTION_KEYS = ["happiness", "sadness", "anger", "fear", "disgust", "surprise"];
function normalizeEmotionScores(raw) {
  const scores = {};
  let total = 0;
  EMOTION_KEYS.forEach((key) => {
    const value = Number(raw?.[key]);
    const safe = Number.isFinite(value) ? Math.max(0, value) : 0;
    scores[key] = safe;
    total += safe;
  });
  if (total <= 0) {
    const even = Math.floor(100 / EMOTION_KEYS.length);
    let remainder = 100 - even * EMOTION_KEYS.length;
    EMOTION_KEYS.forEach((key) => {
      scores[key] = even + (remainder > 0 ? 1 : 0);
      if (remainder > 0) remainder -= 1;
    });
    return scores;
  }
  const normalized = {};
  let running = 0;
  EMOTION_KEYS.forEach((key, index) => {
    if (index === EMOTION_KEYS.length - 1) {
      normalized[key] = 100 - running;
      return;
    }
    const scaled = Math.round(scores[key] / total * 100);
    normalized[key] = scaled;
    running += scaled;
  });
  return normalized;
}
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return jsonResponse(405, { error: "Method Not Allowed" });
  }
  const body = parseEventBody(event);
  const text = typeof body?.text === "string" ? body.text.trim() : "";
  if (text.length < 10) {
    return jsonResponse(400, { error: "\uB354 \uC790\uC138\uD558\uAC8C \uC368\uC8FC\uC138\uC694." });
  }
  const systemPrompt = `\uB2F9\uC2E0\uC740 \uC74C\uC545 \uAC10\uC0C1 \uD14D\uC2A4\uD2B8\uB97C \uBD84\uC11D\uD558\uC5EC \uAC10\uC815\uC744 \uBD84\uB958\uD558\uB294 \uC804\uBB38\uAC00\uC785\uB2C8\uB2E4.
\uC785\uB825\uB41C \uD14D\uC2A4\uD2B8\uB97C \uC77D\uACE0 \uC544\uB798 6\uAC00\uC9C0 \uAC10\uC815\uC758 \uBE44\uC728\uC744 \uBD84\uC11D\uD558\uC138\uC694.
\uBC18\uB4DC\uC2DC JSON \uD615\uC2DD\uC73C\uB85C\uB9CC \uC751\uB2F5\uD558\uC138\uC694.
\uB2E4\uB978 \uD14D\uC2A4\uD2B8\uB294 \uC808\uB300 \uD3EC\uD568\uD558\uC9C0 \uB9C8\uC138\uC694.
6\uAC00\uC9C0 \uAC10\uC815 \uBE44\uC728\uC758 \uD569\uC740 \uBC18\uB4DC\uC2DC 100\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4.`;
  const userPrompt = `\uB2E4\uC74C \uC74C\uC545 \uAC10\uC0C1 \uC11C\uC220\uC5D0\uC11C \uB290\uAEF4\uC9C0\uB294 \uAC10\uC815\uC744 \uBD84\uC11D\uD574\uC8FC\uC138\uC694: ${text}

\uC751\uB2F5 \uD615\uC2DD:
{
  "happiness": \uC22B\uC790,
  "sadness": \uC22B\uC790,
  "anger": \uC22B\uC790,
  "fear": \uC22B\uC790,
  "disgust": \uC22B\uC790,
  "surprise": \uC22B\uC790,
  "summary": "\uD55C \uBB38\uC7A5 \uC694\uC57D (\uD55C\uAD6D\uC5B4)"
}`;
  try {
    const json = await callOpenAiResponses({
      model: "gpt-4o-mini",
      input: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ]
    });
    const rawText = extractTextFromResponse(json);
    const parsed = JSON.parse(rawText);
    const emotions = normalizeEmotionScores(parsed);
    const summary = typeof parsed?.summary === "string" ? parsed.summary.trim() : "";
    return jsonResponse(200, {
      emotions,
      summary
    });
  } catch (err) {
    const status = err?.statusCode || 500;
    return jsonResponse(status, {
      error: err?.message || "\uAC10\uC815 \uBD84\uC11D \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4."
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
