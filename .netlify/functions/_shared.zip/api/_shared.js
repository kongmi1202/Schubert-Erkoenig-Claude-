var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// api/_shared.js
var shared_exports = {};
__export(shared_exports, {
  callOpenAiResponses: () => callOpenAiResponses,
  extractTextFromResponse: () => extractTextFromResponse,
  getOpenAiApiKey: () => getOpenAiApiKey
});
module.exports = __toCommonJS(shared_exports);
function extractTextFromResponse(json) {
  if (typeof json?.output_text === "string") return json.output_text;
  const texts = [];
  (json?.output || []).forEach((item) => {
    (item?.content || []).forEach((contentItem) => {
      if (typeof contentItem?.text === "string") texts.push(contentItem.text);
    });
  });
  return texts.join("\n").trim();
}
function getOpenAiApiKey() {
  const key = process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY;
  return typeof key === "string" ? key.trim() : "";
}
async function callOpenAiResponses({ model, input }) {
  const apiKey = getOpenAiApiKey();
  if (!apiKey) {
    const err = new Error("OPENAI_API_KEY\uAC00 \uC124\uC815\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    err.statusCode = 500;
    throw err;
  }
  const openAiRes = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({ model, input })
  });
  const json = await openAiRes.json();
  if (!openAiRes.ok) {
    const err = new Error(typeof json?.error?.message === "string" ? json.error.message : "OpenAI API \uD638\uCD9C \uC2E4\uD328");
    err.statusCode = openAiRes.status;
    err.payload = json;
    throw err;
  }
  return json;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  callOpenAiResponses,
  extractTextFromResponse,
  getOpenAiApiKey
});
